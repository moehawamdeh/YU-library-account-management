package com.mdhawamdeh.comprehensivelegaldictionary.viewmodel;

import android.app.Application;
import android.text.Editable;

import com.mdhawamdeh.comprehensivelegaldictionary.model.FullSearchTask;
import com.mdhawamdeh.comprehensivelegaldictionary.model.SearchResult;
import com.mdhawamdeh.comprehensivelegaldictionary.model.SearchTask;
import com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils;
import com.mdhawamdeh.comprehensivelegaldictionary.model.Term;
import com.mdhawamdeh.comprehensivelegaldictionary.model.TermsSearcher;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.LiveData;


public class SearchVM extends AndroidViewModel implements SearchTask.OnPostExecuteListener {
    private TermsSearcher mTermsSearcher;
    private MutableLiveData<List<Term>> mSearchResult;
    private String mLastSearch;
    private MutableLiveData<SearchError> mError;

    public SearchVM(@NonNull Application application) {
        super(application);
        mTermsSearcher=new TermsSearcher(application);
        mSearchResult=new MutableLiveData<>();
        mError=new MutableLiveData<>();
        mLastSearch="";
    }
    public LiveData<List<Term>>getSearchResult(){
        return mSearchResult;
    }
    public void searchFor(String text) {
        if(!text.trim().isEmpty())
        {
            SearchTask task=new FullSearchTask(mTermsSearcher,this);
            task.execute(text,"true","true","30");
            mLastSearch=text;
            //text/paging/reset/period
        }else{
            mError.setValue(SearchError.EMPTY);
        }
    }
    public void loadMore(){
        if(mLastSearch.isEmpty())
            return;
        SearchTask task=new FullSearchTask(mTermsSearcher,this);
        task.execute(mLastSearch,"true","false","30");
    }

    @Override
    public void onPostExecute(SearchResult searchResult) {
        List<Term> result=searchResult.getTermsList();
        if(result==null||result.isEmpty())
            mSearchResult.setValue(null);
        else mSearchResult.setValue(result);
    }

    public boolean isEnglish(String text) {
        return SearchUtils.isEnglish(text);
    }

    public String getLastSearch() {
        return mLastSearch;
    }

    public enum SearchError{
        EMPTY,NOT_FOUND
    }
    public LiveData<SearchError> getError() {
        return mError;
    }
}
