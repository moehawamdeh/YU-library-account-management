package com.mdhawamdeh.comprehensivelegaldictionary.view;

import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils;
import com.mdhawamdeh.comprehensivelegaldictionary.model.Term;
import com.mdhawamdeh.comprehensivelegaldictionary.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TermAdapter extends RecyclerView.Adapter<TermAdapter.TermHolder>{
    private final int TYPE_EXTENDED=13;
    private final int TYPE_SHORT=21;
    private int mViewType=TYPE_SHORT;
    private List<Term> resultList=new ArrayList<>();
    private OnTermSelectedListener mListener;
    private String mSelection;
    private boolean mEnglishSelection;
    public void setSelection(String selection,boolean isEnglish) {
        if(selection.isEmpty())
            return;
        mSelection = selection;
        mEnglishSelection=isEnglish;
        Log.i("UI_DEBUG","set selection");

    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    TermAdapter(OnTermSelectedListener listener){
        mListener=listener;
        mSelection="";
    }
    TermAdapter(String selection,boolean englishSelection){
        mSelection=selection;
        mEnglishSelection=englishSelection;
    }
    @NonNull
    @Override
    public TermHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        int layout_id=viewType==TYPE_EXTENDED?R.layout.item_term_extended:R.layout.item_term;
        return new TermHolder(inflater.inflate(layout_id,parent,false));
    }

    @Override
    public int getItemViewType(int position) {
        return mViewType;
    }
    public void setTYPE_EXTENDED(boolean set){
        mViewType=set?TYPE_EXTENDED:TYPE_SHORT;
    }
    @Override
    public void onBindViewHolder(@NonNull TermHolder holder, int position) {
        holder.bind(resultList.get(position));
    }

    @Override
    public int getItemCount() {
        return resultList.size();
    }

    void setResultList(List<Term> result) {
        mSelection="";
        this.resultList.clear();
        if(result!=null)
            this.resultList.addAll(result);
        this.notifyDataSetChanged();

    }
    void addResults(List<Term>results){
        if(results==null||results.isEmpty())
            return;
        this.resultList.addAll(results);
        this.resultList=new ArrayList<>(this.resultList);
        notifyDataSetChanged();
    }

    public int getSize() {
        if(resultList!=null)
        return resultList.size();
        return -1;
    }

    interface OnTermSelectedListener {
        void onTermSelected(Term term);
    }
    class TermHolder extends RecyclerView.ViewHolder {

        TermHolder(@NonNull View itemView) {
            super(itemView);
        }

        void bind(final Term term) {
            Log.i("UI_DEBUG","bind item");

            if(this.getItemViewType()==TYPE_EXTENDED)
            {
                TextView english = itemView.findViewById(R.id.text_english);
                TextView arabic = itemView.findViewById(R.id.text_arabic);
                if(mSelection.isEmpty())
                {
                    english.setText(term.getTerm());
                    arabic.setText(term.getTranslation());
                }else{
                    if(mEnglishSelection)
                    {
                        Spannable word=new SpannableString(term.getTerm());
                        Pair<Integer,Integer> range=SearchUtils.indexOf(term.getTerm(),mSelection);
                        if(range==null){
                            english.setText(term.getTerm());
                        }else{
                            int start=range.first;
                            int end=range.second;
                            word.setSpan(new ForegroundColorSpan(Color.BLUE), start, end+1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                            english.setText(word);
                        }
                        arabic.setText(term.getTranslation());
                    }else{
                        Spannable word=new SpannableString(term.getTranslation());
                        Pair<Integer,Integer> range=SearchUtils.indexOf(term.getTranslation(),mSelection);
                        if(range==null){
                            arabic.setText(term.getTranslation());
                        }else{
                            int start=range.first;
                            int end=range.second;
                            word.setSpan(new ForegroundColorSpan(Color.BLUE), start, end+1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                            arabic.setText(word);
                        }
                        english.setText(term.getTerm());
                    }
                }
            }
            else {
                TextView termV = itemView.findViewById(R.id.text_term);
                TextView transV = itemView.findViewById(R.id.text_translation);
                termV.setText(term.getTerm());
                transV.setText(term.getTranslation());
            }
            if(mListener!=null)
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mListener!=null)
                    mListener.onTermSelected(term);
                }
            });
        }
    }
}