package com.mdhawamdeh.comprehensivelegaldictionary.model;

import java.util.List;

public class FullSearchTask extends SearchTask {

    public FullSearchTask(TermsSearcher searcher, OnPostExecuteListener listener) {
        super(searcher, listener);
    }

    @Override
    SearchResult search(String... strings) {
        final long start=System.currentTimeMillis();
        String text=strings[0],paging=strings[1],resetPaging=strings[2];
        if(Boolean.parseBoolean(paging)){
            int period= Integer.parseInt(strings[3]);
            mSearcher.get().setPaging(true,period);
        }
        if(Boolean.parseBoolean(resetPaging))
            mSearcher.get().resetPaging();

        final SearchResult searchResult =new SearchResult();
        mSearcher.get().searchFor(text, new TermsSearcher.OnResultListener() {
            @Override
            public void onResult(boolean exactMatch, List<Term> results) {
                searchResult.setTermsList(results);
            }
        });
        return searchResult;
    }
}
