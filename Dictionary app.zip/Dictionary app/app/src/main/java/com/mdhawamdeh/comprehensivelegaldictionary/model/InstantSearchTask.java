package com.mdhawamdeh.comprehensivelegaldictionary.model;

import java.util.List;

public class InstantSearchTask extends SearchTask {

    public InstantSearchTask(TermsSearcher searcher, OnPostExecuteListener listener) {
        super(searcher, listener);
    }

    @Override
    SearchResult search(String... strings) {
        final long start=System.currentTimeMillis();
        String text=strings[0];
        int lang= Integer.parseInt(strings[1]);
        final SearchResult searchResult =new SearchResult();
        mSearcher.get().searchInstantFor(text, lang, new TermsSearcher.OnResultListener() {
            @Override
            public void onResult(boolean exactMatch, List<Term> results) {
                searchResult.setMatch(exactMatch);
                searchResult.setTermsList(results);
                searchResult.setTime((int) (System.currentTimeMillis()-start));
            }
        });
        return searchResult;
    }
}
