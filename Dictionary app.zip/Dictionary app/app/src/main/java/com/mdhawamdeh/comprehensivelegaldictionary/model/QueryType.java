package com.mdhawamdeh.comprehensivelegaldictionary.model;

public enum QueryType {
    wildCardEnd,wildCardBoth,translation,Full
}
