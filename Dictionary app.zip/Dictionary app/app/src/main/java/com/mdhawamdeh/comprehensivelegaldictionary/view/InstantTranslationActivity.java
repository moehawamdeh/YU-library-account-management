package com.mdhawamdeh.comprehensivelegaldictionary.view;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.mdhawamdeh.comprehensivelegaldictionary.R;
import com.mdhawamdeh.comprehensivelegaldictionary.model.Term;
import com.mdhawamdeh.comprehensivelegaldictionary.model.TermsSearcher;
import com.mdhawamdeh.comprehensivelegaldictionary.viewmodel.InstantTranslationVM;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.speech.RecognizerIntent.EXTRA_RESULTS;

public class InstantTranslationActivity extends AppCompatActivity implements TextToSpeech.OnInitListener,TextWatcher,View.OnClickListener,TermAdapter.OnTermSelectedListener {
    private static final int REQUEST_VOICE_RECOGNITION = 1010;
    private static final int ACT_CHECK_TTS_DATA =212 ;
    private RecyclerView mRecyclerView;
    private TermAdapter mAdapter;
    private EditText mText;
    private TextView mTranslation;
    private TextView mArabic;
    private TextView mEnglish;
    private ImageButton mVoiceButton;
    private ImageButton mCopyButton;
    private ImageButton mClearButton;
    private ImageButton mTTSButton;
    private InstantTranslationVM mViewModel;
    private TextToSpeech mTTS = null;
    private void initializeViews(){
        mRecyclerView =findViewById(R.id.recyclerView);
        mTranslation =findViewById(R.id.text_result);
        mText =findViewById(R.id.feild_term);
        mArabic=findViewById(R.id.text_arabic);
        mEnglish=findViewById(R.id.text_english);
        mClearButton=findViewById(R.id.button_clear);
        mCopyButton =findViewById(R.id.button_copy);
        mVoiceButton=findViewById(R.id.button_voice);
        mTTSButton=findViewById(R.id.button_tts);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intant_translation);
        //////
        initializeViews();
        mTTS = new TextToSpeech(this, this);//talk to speak

        mViewModel=ViewModelProviders.of(this).get(InstantTranslationVM.class);
        mViewModel.setEnglish();

        mAdapter=new TermAdapter(this);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);

        mText.addTextChangedListener(this);
        findViewById(R.id.button_swap).setOnClickListener(this);
        mArabic.setOnClickListener(this);
        mEnglish.setOnClickListener(this);
        mClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mText.setText("");
            }
        });
        mVoiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startVoiceRecognition();
            }
        });
        mCopyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                copyToClipboard();
            }
        });
        findViewById(R.id.button_clear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { mText.setText("");
            }
        });
        mTTSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saySomething(mTranslation.getText().toString(),0);
            }
        });
        mClearButton.setColorFilter(ContextCompat.getColor(this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
        mTTSButton.setColorFilter(ContextCompat.getColor(this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
        mCopyButton.setColorFilter(ContextCompat.getColor(this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
        mClearButton.setEnabled(false);
        mTTSButton.setEnabled(false);
        mCopyButton.setEnabled(false);
        mViewModel.getMatchTerm().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String match) {

                if(match==null)
                {
                    mTTSButton.setEnabled(false);
                    mTTSButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
                    mTranslation.setText(R.string.no_exact_translation);
                    mCopyButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
                    mCopyButton.setEnabled(false);
                }
                else if(match.isEmpty())
                {
                    mTTSButton.setEnabled(false);
                    mTTSButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
                    mTranslation.setText("...");
                    mTranslation.setText(R.string.no_exact_translation);
                    mCopyButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
                }
                else {

                    mTTSButton.setEnabled(!mViewModel.isEnglish());
                    mTTSButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, mViewModel.isEnglish()?R.color.colorDisabled:R.color.colorSecondaryLight), android.graphics.PorterDuff.Mode.SRC_IN);
                    mTranslation.setText(match);
                    mCopyButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, R.color.colorSecondaryLight), android.graphics.PorterDuff.Mode.SRC_IN);
                    mCopyButton.setEnabled(true);
                } }
        });
        mViewModel.getSimilarTerms().observe(this, new Observer<List<Term>>() {
            @Override
            public void onChanged(List<Term> terms) {
                mAdapter.setResultList(terms);
            }
        });
    }

    private void copyToClipboard() {
        ClipboardManager manager=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        ClipData data=ClipData.newPlainText("Translated term",mTranslation.getText());
        if(manager!=null)
        manager.setPrimaryClip(data);
    }

    private void startVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,mViewModel.isEnglish()?"en":"ar");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1); // number of maximum results..
        try {
            startActivityForResult(intent, REQUEST_VOICE_RECOGNITION);
        }catch (ActivityNotFoundException e){
            new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.voice_recognition))
                    .setMessage(getString(R.string.error_no_voice_recog))
                    // Specifying a listener allows you to take an action before dismissing the dialog.
                    // The dialog is automatically dismissed when a dialog button is clicked.
                    .setPositiveButton(android.R.string.ok,null)
                    // A null listener allows the button to dismiss the dialog and take no further action.
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
            mVoiceButton.setEnabled(false);
            mVoiceButton.setColorFilter(ContextCompat.getColor(this, R.color.colorDisabled), android.graphics.PorterDuff.Mode.SRC_IN);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUEST_VOICE_RECOGNITION)
        {if(resultCode==RESULT_OK) {
            if (data != null)
                if (data.hasExtra(EXTRA_RESULTS))
                {
                    mText.setText(data.getStringArrayListExtra(EXTRA_RESULTS).get(0));
                    moveCursorToEnd();//to move cursor to end
                }
            }
        }else if (requestCode == ACT_CHECK_TTS_DATA) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                // Data exists, so we instantiate the TTS engine
                mTTS = new TextToSpeech(this, this);
            } else {
                // Data is missing, so we start the TTS
                // installation process
                Intent installIntent = new Intent();
                installIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(installIntent);
            }
        }
    }
    private void saySomething(String text, int qmode) {
        if (qmode == 1)
            mTTS.speak(text, TextToSpeech.QUEUE_ADD, null);
        else
            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }


    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }
    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }
    @Override
    public void afterTextChanged(Editable editable) {
        String text=editable.toString();
        mViewModel.setText(text);
        mClearButton.setColorFilter(ContextCompat.getColor(InstantTranslationActivity.this, text.isEmpty()?R.color.colorDisabled:R.color.colorSecondaryLight), android.graphics.PorterDuff.Mode.SRC_IN);
        mClearButton.setEnabled(!text.isEmpty());
    }

    @Override
    public void onClick(View view) {
        TextView selected,old;
        if(mViewModel.isEnglish()){
            old=mEnglish;
            selected=mArabic;
            mViewModel.setArabic();
        }else {
            selected=mEnglish;
            old=mArabic;
            mViewModel.setEnglish();
        }
        mViewModel.setText(mText.getText().toString());
        selected.setTextSize(TypedValue.COMPLEX_UNIT_PX,getResources().getDimension(R.dimen.text_selected));
        old.setTextSize(TypedValue.COMPLEX_UNIT_PX,getResources().getDimension(R.dimen.text_medium));
    }

    @Override
    public void onTermSelected(Term term) {
        mText.setText(term.getTerm());
        moveCursorToEnd();// to move cursor to end
    }
    private void moveCursorToEnd(){
        mText.post(new Runnable() {
            @Override
            public void run() {
                mText.setSelection(mText.getText().length());
            }
        });
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            if (mTTS != null) {
                Locale loc = new Locale(mViewModel.isEnglish()?"en":"ar");
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    String voiceName;
                    voiceName = loc.toLanguageTag();
                    Voice voice = new Voice(voiceName, loc, Voice.QUALITY_HIGH, Voice.LATENCY_HIGH, false, null);
                    mTTS.setVoice(voice);
                }
                int result = mTTS.setLanguage(loc);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Toast.makeText(this, R.string.tts_language_not_supported, Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this, "TTS initialization failed",
                    Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onDestroy() {
        // Don't forget to shutdown!
        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }
        super.onDestroy();
    }
}
