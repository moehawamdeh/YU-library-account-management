package com.mdhawamdeh.comprehensivelegaldictionary.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;
import com.mdhawamdeh.comprehensivelegaldictionary.R;
import com.mdhawamdeh.comprehensivelegaldictionary.model.Term;
import com.mdhawamdeh.comprehensivelegaldictionary.viewmodel.SearchVM;

import java.util.List;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener,Observer<List<Term>> {
//    private static final String KEY_RECYCLER_STATE = "KRS";
    private SearchVM mViewModel;
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private TermAdapter mAdapter;
    private Button mLoadMore;
    private EditText mEditText;
//    private static Bundle mBundleRecyclerViewState;
    private boolean FLAG_LOAD =false;
    private boolean FLAG_CAN_SCROLL=true;
    private boolean FLAG_CAN_LOAD=true;
    private boolean FLAG_SEARCH_CLICKED=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mLayoutManager=new LinearLayoutManager(this);
        mViewModel=ViewModelProviders.of(this).get(SearchVM.class);
        mAdapter=new TermAdapter(null);
        mAdapter.setTYPE_EXTENDED(true);
        mRecyclerView=findViewById(R.id.recyclerView);
        mRecyclerView.setLayoutManager(mLayoutManager);
       // if(savedInstanceState!=null)
           // mAdapter=new TermAdapter(mViewModel.getLastSearch(),mViewModel.isEnglish(mViewModel.getLastSearch()));
        mRecyclerView.setAdapter(mAdapter);
        mLoadMore=findViewById(R.id.load_more);
        mEditText=findViewById(R.id.inputSearch);
        findViewById(R.id.button_search).setOnClickListener(this);
        mViewModel.getSearchResult().observe(this, this);
        mViewModel.getError().observe(this, new Observer<SearchVM.SearchError>() {
            @Override
            public void onChanged(SearchVM.SearchError error) {
                if(error == SearchVM.SearchError.EMPTY){
                    if(FLAG_SEARCH_CLICKED)
                    Snackbar.make(findViewById(R.id.snack_bar_container),getString(R.string.write_something),Snackbar.LENGTH_SHORT).show();
                    FLAG_SEARCH_CLICKED=false;
                }
            }
        });

        RecyclerView.OnScrollListener mScrollListener = new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (FLAG_LOAD || dy<=0)
                {
                    if(!FLAG_CAN_SCROLL)
                    {
                        mLoadMore.setVisibility(View.GONE);
                        Log.d("UI_DEBUG","scroll");
                        FLAG_CAN_SCROLL=true;
                    }
                }
                else if(!recyclerView.canScrollVertically(1)) {
                    if(FLAG_CAN_LOAD)
                        mLoadMore.setVisibility(View.VISIBLE);
                    Log.d("UI_DEBUG","cant scroll");
                    FLAG_CAN_SCROLL=false;

                }
            }
        };
        mRecyclerView.addOnScrollListener(mScrollListener);
        mLoadMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FLAG_LOAD =true;
                mViewModel.loadMore();
            }
        });
    }

    @Override
    public void onClick(View view) {
        FLAG_LOAD =false;
        FLAG_CAN_LOAD=true;
        FLAG_SEARCH_CLICKED=true;
        mViewModel.searchFor(mEditText.getText().toString());
    }

    @Override
    public void onChanged(List<Term> terms) {
        FLAG_SEARCH_CLICKED=false;
        int previousPosition=mAdapter.getSize();
        if(FLAG_LOAD)
        {
            FLAG_LOAD=false;
            if(terms.size()>0)
            {
                mAdapter.addResults(terms);
                if(previousPosition>0)
                    mRecyclerView.smoothScrollToPosition(previousPosition);
                if(terms.size()<30)
                    FLAG_CAN_LOAD=false;
            }
            else FLAG_CAN_LOAD=false;
            mLoadMore.setVisibility(View.GONE);
        }
        else
        {
            mRecyclerView.smoothScrollToPosition(0);
            mAdapter.setResultList(terms);
            mAdapter.setSelection(mEditText.getText().toString(),mViewModel.isEnglish(mEditText.getText().toString()));
        }
    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        mBundleRecyclerViewState = new Bundle();
//        RecyclerView.LayoutManager manager=mRecyclerView.getLayoutManager();
//        if(manager!=null) {
//            Parcelable listState = manager.onSaveInstanceState();
//            mBundleRecyclerViewState.putParcelable(KEY_RECYCLER_STATE, listState);
//        }
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        // restore RecyclerView state
//        if (mBundleRecyclerViewState != null) {
//            Parcelable listState = mBundleRecyclerViewState.getParcelable(KEY_RECYCLER_STATE);
//            RecyclerView.LayoutManager manager=mRecyclerView.getLayoutManager();
//            if(manager!=null)
//            manager.onRestoreInstanceState(listState);
//        }
//    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if(mAdapter!=null)
        mAdapter.setSelection(mViewModel.getLastSearch(),mViewModel.isEnglish(mViewModel.getLastSearch()));
    }
}
