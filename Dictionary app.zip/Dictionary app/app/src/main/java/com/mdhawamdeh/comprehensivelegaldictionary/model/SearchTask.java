package com.mdhawamdeh.comprehensivelegaldictionary.model;
import android.os.AsyncTask;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.util.List;

public abstract class SearchTask extends AsyncTask<String,List<Term>,SearchResult> {
    protected WeakReference<TermsSearcher> mSearcher;
    private OnPostExecuteListener mListener;
    private String taskTextID;
    public SearchTask(TermsSearcher searcher, OnPostExecuteListener listener){
        mSearcher=new WeakReference<>(searcher);
        mListener=listener;
    }
    @Override
    protected SearchResult doInBackground(String... strings) {
        return search(strings);
    }
    abstract SearchResult search(String... strings);
    protected void onPostExecute(SearchResult searchResult) {
        super.onPostExecute(searchResult);
        if(mListener!=null){
            mListener.onPostExecute(searchResult);
        }
        Log.d("TASK_DEBUG","Task done for"+taskTextID);

    }
    public interface OnPostExecuteListener{
        void onPostExecute(SearchResult searchResult);
    }
}
