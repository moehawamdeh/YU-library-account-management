package com.mdhawamdeh.comprehensivelegaldictionary.model;

import android.util.Pair;

public final class SearchUtils {
    public static final int LANG_AR=0;
    public static final int LANG_EN=1;
    public static String filterText(String text,int lang){
        if(lang == LANG_EN){
            text =text.toLowerCase();
        }else if(lang == LANG_AR){
            text=text.replaceAll("[أإ]","ا");
            text=text.replaceAll("[ة]","ه");
            text=text.replaceAll("[ًٌٍَُِّْ]","");
        }
        return text.replaceAll("[-@!\\-.=#)(*_+,~&^%$\\\\\\[\\]]","").replaceAll("[ ]{2,}"," ").trim();
    }
    public static String filterText(String text) {
        return filterText(filterText(text,LANG_AR),LANG_EN);
    }
    public static boolean isEnglish(String text) {
        int eP=0;
        for (char c:text.toCharArray()) {
            if((c>='a'&& c<='z' )|| (c>='A' && c<='Z')){
                eP++;
            }
        }
        return eP>text.length()/2;
    }

    public static Pair<Integer,Integer> indexOf(String term, String selection) {
        char[] fTerm=term.toLowerCase().toCharArray();
        char[] fSelection=selection.toLowerCase().toCharArray();
        boolean potentialMatch=false;
        int index=-1,lastIndex=-1,subIndex=0;
        boolean found=false;
        for(int i=0;i<term.length();i++){
            if(!potentialMatch && fTerm[i]==fSelection[0]){
                index=i;
                if(subIndex==selection.length()-1){
                    lastIndex=i;
                    return new Pair<>(index,lastIndex);
                }
                potentialMatch=true;//88
                subIndex=1;
                continue;
            }
            if(potentialMatch){
                if(isFilteredChar(fTerm[i]))
                    continue;
                if(fTerm[i]==fSelection[subIndex]){
                    if(subIndex==selection.length()-1){
                        lastIndex=i;
                        return new Pair<>(index,lastIndex);

                    }
                    subIndex++;
                }else potentialMatch=false;
            }

        }
        return null;
    }

    private static boolean isFilteredChar(char c) {
        String filter="[-@!\\-=#)(*_+,~&^%$\\\\\\[\\]]"+"ًٌٍَُِّْ";
        return filter.contains(String.valueOf(c));
    }
}
