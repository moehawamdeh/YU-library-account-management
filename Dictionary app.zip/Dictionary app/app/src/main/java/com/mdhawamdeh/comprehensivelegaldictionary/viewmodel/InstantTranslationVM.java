package com.mdhawamdeh.comprehensivelegaldictionary.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.mdhawamdeh.comprehensivelegaldictionary.model.InstantSearchTask;
import com.mdhawamdeh.comprehensivelegaldictionary.model.SearchResult;
import com.mdhawamdeh.comprehensivelegaldictionary.model.SearchTask;
import com.mdhawamdeh.comprehensivelegaldictionary.model.Term;
import com.mdhawamdeh.comprehensivelegaldictionary.model.TermsSearcher;

import java.util.List;

import static com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils.LANG_AR;
import static com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils.LANG_EN;

public class InstantTranslationVM extends AndroidViewModel implements SearchTask.OnPostExecuteListener {
    private MutableLiveData<String> mMatchTerm;
    private MutableLiveData<List<Term>>mSimilarTerms;
    private boolean mIsEnglish=true;
    private TermsSearcher mTermsSearcher;
    public LiveData<String> getMatchTerm(){
        return mMatchTerm;
    }
    public LiveData<List<Term>> getSimilarTerms(){
        return mSimilarTerms;
    }
    public InstantTranslationVM(@NonNull Application application) {
        super(application);
        mMatchTerm =new MutableLiveData<>();
        mSimilarTerms=new MutableLiveData<>();
        mTermsSearcher=new TermsSearcher(application);

    }
    public void setText(String text){
        if(text.isEmpty())
        {
            mMatchTerm.setValue("");
            mSimilarTerms.setValue(null);
        }else{
            SearchTask task=new InstantSearchTask(mTermsSearcher,this);
            task.execute(text,String.valueOf(mIsEnglish?LANG_EN:LANG_AR));
        }
    }
    public void setEnglish(){
        mIsEnglish=true;
    }
    public void setArabic(){
        mIsEnglish=false;
    }
    public boolean isEnglish(){
        return mIsEnglish;
    }
    @Override
    public void onPostExecute(SearchResult searchResult) {
        List<Term> results= searchResult.getTermsList();
        if(results==null)
        {
            mSimilarTerms.setValue(null);
            mMatchTerm.setValue(null);
        }
        else{
            if(searchResult.isMatch())
            {
                mMatchTerm.setValue(results.get(0).getTranslation());
                results.remove(0);
            }else mMatchTerm.setValue("");
            mSimilarTerms.setValue(results);
        }
    }
}
