package com.mdhawamdeh.comprehensivelegaldictionary.model;

import java.util.List;

public class SearchResult {
    private List<Term> termsList;
    private boolean match;

    public void setTime(int time) {
        this.time = time;
    }

    int time;
    public SearchResult(List<Term>list, boolean matchFirst){
        match=matchFirst;
        termsList =list;
    }
    public SearchResult(){

    }

    public List<Term> getTermsList() {
        return termsList;
    }

    public void setTermsList(List<Term> termsList) {
        this.termsList = termsList;
    }

    public boolean isMatch() {
        return match;
    }

    public void setMatch(boolean match) {
        this.match = match;
    }

    public int getTime() {
        return time;
    }
}