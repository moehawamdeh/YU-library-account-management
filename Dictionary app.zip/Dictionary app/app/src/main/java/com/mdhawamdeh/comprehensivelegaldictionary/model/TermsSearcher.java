package com.mdhawamdeh.comprehensivelegaldictionary.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import static com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils.LANG_AR;
import static com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils.LANG_EN;
import static com.mdhawamdeh.comprehensivelegaldictionary.model.SearchUtils.filterText;

public class TermsSearcher extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_NAME_EN = "en_terms";
    private static final String TABLE_NAME_AR = "ar_terms";
    private static final String TABLE_NAME_TRANSLATION = "translation";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TERM = "term";
    private static final String COLUMN_EN = "en";
    private static final String COLUMN_AR = "ar";
    private static String DB_NAME = "law_dictionary";
    private Context mContext;
    private int mPage =1,mPeriod;
    private  boolean doPaging =false;

    public void setPaging(boolean doPaging,int period) {
        if(doPaging)
        mPeriod=period;
        this.doPaging = doPaging;
    }
    public void resetPaging(){
        mPage=1;
    }

    public TermsSearcher(Context context) {
        super(context, DB_NAME, null, DATABASE_VERSION);
        mContext =context;
        if(!checkDataBase())
        {
            Log.d("DB_DEBUG","DB does'nt exist");
            try {
                Log.d("DB_Debug","copying DB");
                getWritableDatabase();
                copyDataBase();
                Log.d("DB_Debug","DB copied");

            } catch (IOException e) {
                context.deleteDatabase(DB_NAME);
                Log.d("DB_Debug","error copying DB");
                Log.d("DB_DEBUG",e.getMessage());
                throw new Error("Error copying database");
            }
        }
        if(!getReadableDatabase().isOpen())
        {
            Log.d("DB_DEBUG","Connection was Closed Open");
            SQLiteDatabase.openDatabase(getPath(),null,SQLiteDatabase.OPEN_READONLY);
        }
        else {
            Log.d("DB_DEBUG","Connection is Already Open");
        }

    }
    public void searchFor(String text,OnResultListener listener){
        text=filterText(text);
        if(text.isEmpty())
            listener.onResult(false,null);
        List<Term>result=queryTerms(QueryType.Full,text,-1);
        if(result.size()>0)
            listener.onResult(false,result);
        else listener.onResult(false,null);
    }


    public void searchInstantFor(String text, int lang, OnResultListener listener){
        Log.d("DB_DEBUG","Start At "+System.currentTimeMillis());
        text = filterText(text,lang);
        List<Term>results=queryTerms(QueryType.wildCardEnd,text,lang);
        if(results.size()>0){
            String ids=toCommaString(results);
            List<Term>translations=queryTerms(QueryType.translation,ids,lang);
            String first=translations.get(0).getTerm();
            if(filterText(first,lang).equals(text))
            {
                listener.onResult(true,translations);
            }else listener.onResult(false,translations);

        }
        else{
            results=queryTerms(QueryType.wildCardBoth,text,lang);
            if(results.isEmpty())
                listener.onResult(false,null);
            else{
                String ids=toCommaString(results);
                List<Term>translations=queryTerms(QueryType.translation,ids,lang);
                listener.onResult(false,translations);
            }
        }
        Log.d("DB_DEBUG","End At "+System.currentTimeMillis());
    }
    private String toCommaString(List<Term> results) {
        StringBuilder text= new StringBuilder();
        for(int i=0;i<results.size();i++){
            if(i==0)
                text.append(results.get(i).getId());
            else text.append(",").append(results.get(i).getId());
        }
        return text.toString();
    }
    private List<Term> queryTerms(QueryType type,String selection,int lang) {
        List<Term> terms = new ArrayList<>();
        Cursor cursor = getQueryCursor(type, selection, lang);
        if (type == QueryType.translation) {
            int
                    id = cursor.getColumnIndex(COLUMN_ID),
                    term = cursor.getColumnIndex((lang == LANG_EN ? COLUMN_EN : COLUMN_AR)),
                    translation = cursor.getColumnIndex((lang != LANG_EN ? COLUMN_EN : COLUMN_AR));
            if (cursor.moveToFirst()) {
                do {
                    terms.add(new Term(cursor.getString(id), cursor.getString(term), cursor.getString(translation)));
                } while (cursor.moveToNext());
            }
            cursor.close();
            return terms;
        }else if(type==QueryType.Full){
            int id = cursor.getColumnIndex(COLUMN_ID),
                    term = cursor.getColumnIndex(COLUMN_EN),
                    translation = cursor.getColumnIndex(COLUMN_AR);
            if (cursor.moveToFirst()) {
                do {
                    terms.add(new Term(cursor.getString(id), cursor.getString(term), cursor.getString(translation)));
                } while (cursor.moveToNext());
            }
            cursor.close();
            return terms;
        }
        else  {
            if (cursor.moveToFirst()) {
                do {
                    terms.add(new Term(cursor.getString(0)));
                } while (cursor.moveToNext());
            }
            cursor.close();
            return terms;
        }
    }
    private Cursor getQueryCursor(QueryType type,String selection,int lang){
        String query;
        String[] args=null;
        if(type==QueryType.translation)
          query="select * from "+TABLE_NAME_TRANSLATION+" where "+COLUMN_ID+" in ("+selection+");";
        else if(lang==-1){
            String table=figureLanguage(selection);
            String limit=doPaging?(" limit "+mPage+", "+(mPage+mPeriod)):"";
            mPage+=mPeriod+1;
            String subQuery1="select "+COLUMN_ID+",length("+COLUMN_TERM+"),1 as priority from "+table+" where "+COLUMN_TERM+" like ?";
            String subQuery2="select "+COLUMN_ID+",length("+COLUMN_TERM+"),0 as priority from "+table+" where "+COLUMN_TERM+" like ?";
            String combinedQuery="select "+COLUMN_ID+" from ("+subQuery1+" union "+subQuery2+" order by priority desc,length("+COLUMN_TERM+"))";
            query="select * from "+TABLE_NAME_TRANSLATION+
                    " as T join ("+combinedQuery+") as R where T."+COLUMN_ID+"=R."+COLUMN_ID+limit+";";
            selection=selection+'%';
            args=new String[]{selection,'%'+selection};
        }
        else {
            String table=(lang==LANG_AR?TABLE_NAME_AR:TABLE_NAME_EN);
            query="select "+COLUMN_ID+" from "+table+" where "+COLUMN_TERM+" like ? order by length("+COLUMN_TERM+") limit 7";
            if(type==QueryType.wildCardBoth)
                selection="%"+selection;
            selection=selection+"%";
            args=new String[]{selection};
        }
        if(args==null)
            Log.d("DB_DEBUG","Query: "+query);
        else Log.d("DB_DEBUG","Query: "+query.replace("?",args[0]));
        return getReadableDatabase().rawQuery(query,args);
    }

    private String figureLanguage(String selection) {
        int eP=0;
        for (char c:selection.toCharArray()) {
            if((c>='a'&& c<='z' )|| (c>='A' && c<='Z')){
                eP++;
            }
        }
        return eP>selection.length()/2?TABLE_NAME_EN:TABLE_NAME_AR;
    }

    public interface OnResultListener{
        void onResult(boolean exactMatch,List<Term> results);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.d("DB_DEBUG","Upgrade detected");
        mContext.deleteDatabase(DB_NAME);
        Log.d("DB_DEBUG","Old DB deleted");
        try {
            Log.d("DB_Debug","copying DB");
            copyDataBase();
            Log.d("DB_Debug","DB copied");

        } catch (IOException e) {
            Log.d("DB_Debug", "error copying DB");
            throw new Error("Error copying database");
        }

    }
    private boolean checkDataBase(){

        File dbFile = mContext.getDatabasePath(DB_NAME);
        return dbFile.exists();
    }
    private String getPath(){
        return mContext.getDatabasePath(DB_NAME).getPath();
    }
    private void copyDataBase() throws IOException {

        //Open your local db as the input stream
        InputStream myInput = mContext.getAssets().open(DB_NAME+".db");

        // Path to the just created empty db
        String outFileName = getPath();

        //Open the empty db as the output stream
        OutputStream myOutput = new FileOutputStream(outFileName);

        //transfer bytes from the inputfile to the outputfile
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer))>0){
            myOutput.write(buffer, 0, length);
        }

        //Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();


    }
    public  void closeConnection(){
        //no need
    }

}
