package com.mdhawamdeh.comprehensivelegaldictionary.model;

public class Term {
    private String term;
    private String translation;

    public Term(String id) {
        this.id = id;
    }
    public Term(String id,String term,String translation){
        this.id=id;
        this.term=term;
        this.translation=translation;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String id;

    public String getTranslation() {
        return translation;
    }

    public void setTranslation(String translation) {
        this.translation = translation;
    }
}
