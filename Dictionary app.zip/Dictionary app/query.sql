select * from en_terms where term like 'duction%' order by length(term) limit 5;
--if empty
--select *,length(term),instr(lower(term),'duction') from en_terms where term like '%duction%' order by length(term)*instr(lower(term),'duction') limit 5;
select *,length(term),instr(lower(term),'duction') from en_terms where term like '%duction%' order by length(term) limit 5;

--select *,instr(term,'Cat')*length(term) from en_terms where term like '%Cat%' order by (instr(term,'Cat') *length(term)) limit 5;
--select *,instr(term,'cat')*length(term) from en_terms where term like '%cat%' order by length(term),instr(term,'cat') limit 5;